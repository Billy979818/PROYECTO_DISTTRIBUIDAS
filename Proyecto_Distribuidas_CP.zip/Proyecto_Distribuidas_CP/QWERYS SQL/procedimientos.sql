 
select * from cliente 