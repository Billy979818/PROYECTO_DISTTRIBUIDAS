/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_distribuidas_cp;
import Pantallas.*;
import Conexion.*;
import java.sql.SQLException;

/**
 *
 * @author ALEJITA PC
 */
public class Proyecto_Distribuidas_CP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
                
     //Logueo_Credenciales logueo = new Logueo_Credenciales();
     //logueo.setVisible(true);
     PantallaPrincipalLogueo principal = new PantallaPrincipalLogueo();
     principal.setVisible(true);
     
    }
    
}
