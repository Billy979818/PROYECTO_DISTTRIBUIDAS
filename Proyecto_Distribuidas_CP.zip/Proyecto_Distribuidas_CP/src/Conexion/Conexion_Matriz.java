/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author ALEJITA PC
 */
public class Conexion_Matriz  {
    
    static Connection conector = null;
    public static String usuario;
    public static String password;
    public static boolean estado = false;
    
    public static void setCuenta(String user, String pass){
        Conexion_Matriz.usuario = user;
        Conexion_Matriz.password = pass;
        
    }
    
    public static boolean getStado (){
        return estado;
    }
    
    public static Connection getConexion (){
        
        estado = false;
        String ConnectionURL = "jdbc:sqlserver://DESKTOP-LMKB79I:1433;databaseName=Reserva_Version_final_1";
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            
            
        }catch(ClassNotFoundException e){
            JOptionPane.showMessageDialog(null, "No se pudo establecer la de conexion ....");
        }
        try{
            conector = DriverManager.getConnection(ConnectionURL, usuario, password);
            estado = true;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "No se pudo establecer la de conexion ....");
        }
       
        //System.out.println("Base de datos conectada"); 
        return conector;
    }
    
    public static  ResultSet consulta (String consulta){
        Connection con = getConexion();
        Statement instruccion;
        try{
            instruccion = con.createStatement();
            ResultSet respuesta = instruccion.executeQuery(consulta);
            return respuesta;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "NO SE PUDO REALIZAR LA CONSULTA");
        }
        return null;
    }
    
    
    
}
