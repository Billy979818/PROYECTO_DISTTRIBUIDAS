
package Conexion;

import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.SQLException;

public class Procedimientos {
    
    public static void ingresarClientes(String cedula , String nombre, String apellido, String fechaNac, String telefono )throws SQLException{
       
        CallableStatement ingresar = Conexion_Matriz.getConexion().prepareCall("{call ingresarClientes (?,?,?,?,?) }");
        ingresar.setString(1, cedula);
        ingresar.setString(2, nombre);
        ingresar.setString(3, apellido);
        ingresar.setString(4, fechaNac);
        ingresar.setString(5, telefono);
        ingresar.execute();
        
    }
    
    public static void buscarClienteCedula (String cedula) throws SQLException{
        CallableStatement buscarCedula = Conexion_Matriz.getConexion().prepareCall("{call buscarClienteCedula (?)}");
        buscarCedula.setString(1, cedula);
        buscarCedula.execute();
    }
    
    public static void buscarClienteCedulaNombre (String nombre) throws SQLException{
        CallableStatement buscarNombre = Conexion_Matriz.getConexion().prepareCall("{call buscarClienteNombre (?)}");
        buscarNombre.setString(2, nombre);
        buscarNombre.execute();
    }
    
}
