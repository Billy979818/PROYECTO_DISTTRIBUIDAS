/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validar;

import java.awt.Color;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JTextField;


/**
 *
 * @author u
 */
public class Validar {
    
    public boolean validarCedula(String cedula){
    int suma=0;
    if(cedula.length()!=10){
      System.out.println("Ingrese su cedula de 10 digitos");
      return false;
    }else{
      int a[]=new int [cedula.length()/2];
      int b[]=new int [(cedula.length()/2)];
      int c=0;
      int d=1;
      for (int i = 0; i < cedula.length()/2; i++) {
        a[i]=Integer.parseInt(String.valueOf(cedula.charAt(c)));
        c=c+2;
        if (i < (cedula.length()/2)-1) {
          b[i]=Integer.parseInt(String.valueOf(cedula.charAt(d)));
          d=d+2;
        }
      }
    
      for (int i = 0; i < a.length; i++) {
        a[i]=a[i]*2;
        if (a[i] >9){
          a[i]=a[i]-9;
        }
        suma=suma+a[i]+b[i];
      } 
      int aux=suma/10;
      int dec=(aux+1)*10;
      if ((dec - suma) == Integer.parseInt(String.valueOf(cedula.charAt(cedula.length()-1))))
        return true;
      else
        if(suma%10==0 && cedula.charAt(cedula.length()-1)=='0'){
          return true;
        }else{
          return false;
        }
     
  }
}
    
    
    public boolean validarCamposVacios(List <JTextField> campos){
    boolean bandera=false;//campos estan llenos
    for (int i = 0; i < campos.size(); i++) {
        JTextField txt= campos.get(i);
        if(txt.getText().trim().equals("")){
            txt.setBackground(Color.red);
            bandera= true;
        }
        else{
            txt.setBackground(Color.white);
        }
        txt.revalidate(); 
    }
    return bandera;
}

//LIMPIA TEXT FIELD
public void limpiarCamposVacios(List <JTextField> campos){
    
    for (int i = 0; i < campos.size(); i++) {
        JTextField txt= campos.get(i);
        txt.setText("");
        txt.revalidate();
       
    }
}

 public int validarCorreo(String correo){
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher mather = pattern.matcher(correo);
        if (mather.find() == true) {
			return 1;
		} else {
			return 0;
		}
       
    }
 
  public int validarSueldo(String sueldo){
        Pattern pattern = Pattern.compile("^[0-9]+(\\.)?[\\d]+$");
        Matcher mather = pattern.matcher(sueldo);
        if (mather.find() == true) {
			return 1;
		} else {
			return 0;
		}
       
    }
 
 
 public int validarUsuarioPass(String usuario, String pass){
     int admin =0 ;
     Encriptar encriptar= new Encriptar();
     String passUsuario=encriptar.encriptaEnMD5(usuario);
     String passEncriptado=encriptar.encriptaEnMD5(pass);
 //    EmpleadoDAO empleadoDAO= new EmpleadoDAO(new Coneccion());
   //  int admin=empleadoDAO.buscarEmpleadoLogueo(usuario, pass);
     
     return admin;
 }

}

